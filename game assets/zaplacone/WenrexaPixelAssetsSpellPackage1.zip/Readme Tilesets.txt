Tilesets
Horizontal cell: x15 cells
Vertical cell: x10 cells